"""LibTV Blender Uploader distribution bootstrap."""
bl_info = {'name': 'LibTV 素材导入', 'author': 'LibTV', 'version': (0, 1, 26), 'blender': (3, 6, 0), 'location': 'View3D > Sidebar > LibTV', 'description': 'LibTV 素材导入', 'category': 'Import-Export'}
import base64 as _lx_b
import hashlib as _lx_h
import importlib.util as _lx_u
import json as _lx_j
import os as _lx_o
import sys as _lx_s
import zlib as _lx_z
_lx_k = b'\xc4\xa5\xb8\x93\xa4\x93<\x0e@\xb6m\xe4j\xba\xf2+\xb9\xc9`b\x10\x0c\x04\xd3\x8d]r\x18\xa0(\xbd\xaa'
_lx_p = 'libtv_blender_uploader'  # renamed: folder is blender_uploader; payload keys use original module name
_lx_d = _lx_o.path.dirname(_lx_o.path.abspath(__file__))
_lx_f = _lx_o.path.join(_lx_d, '.lbx')

def _lx_x(data, context):
    output = bytearray(len(data))
    offset = 0
    counter = 0
    while offset < len(data):
        block = _lx_h.sha256(_lx_k + context + counter.to_bytes(4, 'big')).digest()
        size = min(len(block), len(data) - offset)
        for index in range(size):
            output[offset + index] = data[offset + index] ^ block[index]
        offset += size
        counter += 1
    return bytes(output)
with open(_lx_f, 'rb') as _lx_stream:
    _lx_raw = _lx_stream.read()
if _lx_raw[:4] != b'LBX1':
    raise ImportError('Invalid LibTV add-on payload')
_lx_i = _lx_j.loads(_lx_z.decompress(_lx_x(_lx_raw[4:], b'index')).decode('utf-8'))

def _lx_t(name):
    return _lx_h.sha256(name.encode('utf-8')).hexdigest()

def _lx_c(name):
    token = _lx_t(name)
    encrypted = _lx_b.b85decode(_lx_i[token])
    return _lx_z.decompress(_lx_x(encrypted, bytes.fromhex(token)))

_lx_alias = {}


class _LXLoader:

    def create_module(self, spec):
        return None

    def exec_module(self, module):
        old = _lx_alias.get(module.__name__, module.__name__)
        token = _lx_t(old)
        module.__file__ = _lx_f
        code = compile(_lx_c(old), '<lbx:' + token[:8] + '>', 'exec')
        exec(code, module.__dict__, module.__dict__)

class _LXFinder:
    _lbx_owner = _lx_p

    def find_spec(self, fullname, path=None, target=None):
        if fullname.startswith('blender_uploader.'):
            oldname = _lx_p + fullname[len('blender_uploader'):]
            if _lx_t(oldname) in _lx_i:
                _lx_alias[fullname] = oldname
                return _lx_u.spec_from_loader(fullname, _lx_loader, origin=_lx_f)
        return None
for _lx_existing in list(_lx_s.meta_path):
    if getattr(_lx_existing, '_lbx_owner', None) == _lx_p:
        _lx_s.meta_path.remove(_lx_existing)
_lx_loader = _LXLoader()
_lx_s.meta_path.insert(0, _LXFinder())
_lx_entry_name = _lx_p + '.__entry__'
_lx_entry_token = _lx_t(_lx_entry_name)
exec(compile(_lx_c(_lx_entry_name), '<lbx:' + _lx_entry_token[:8] + '>', 'exec'), globals(), globals())
